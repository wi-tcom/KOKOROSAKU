# SAKU Character Pack — サンプル（AMU Studio／SAKU Builder 同梱・評価用）

- pack id / version: `saku-pack-sample` 1.1.0 ／ 収録 3 体（販売 Character のサンプルモード版）
- サンプルモード: 製品版と同じ人格・話し方・第 0 層（hard invariants・人へ渡す条件）・1＋7 の席構成のまま、**得意領域を 1 つに絞り、長文の成果物作成・多段の分析・複数案件の同時進行は行わない**設定にしています（`purpose` のみの調整）。運用区分は製品版と同じ（B の Character は人間確認つき）
- 用途: KOKOROAMU AMU Studio ／ SAKU Builder に同梱される体験用。**評価目的のみ**。製品版は SAKU Character Pack でご利用いただけます（価格は商品ページに記載）
- 形式: KOKOROSAKU Character Pack（profile `saku-unified-v1`、Package 3.0.0）。各 Character は SAKU_UNIFIED_SCHEMA_V1（sha256 48a7241d…）の `character.json`
- 使い方: AMU Studio では「署名付きパック .zip」として取込。SAKU Builder では **01 キャラクターを選択する → Packageインポート**（β.2 以降）
- 署名: 本番鍵（Cloud KMS Ed25519、publisher key id `saku-character-publisher-ed25519.v1` / `saku-pack-publisher-ed25519.v1`）
- pack catalog digest: `sha-256:40e43d2e7cf71d88fba2776beda123928b324181d9cf7a14d494e360c1f0c02c`
- カタログ: `catalog-release.v1.json`（1.1.0-saku-pack-sample.20260922-prod）— `catalog_group: SAMPLE`、code S01〜S03、派生元（character_id・code・characterDigest）と運用区分の判定記録を provenance に記録
- ライセンス: 同梱 `LICENSE.md`（**LicenseRef-WIT-Sample-1.0**、サンプル利用許諾）— 評価目的の利用のみ。再配布・改変・販売 Character への復元は不可。OSS ではありません

| code | 表示名 | character_id | 派生元 | 区分 |
| --- | --- | --- | --- | --- |
| S02 | 逢見 メグル※ | `aimi-meguru-sample` | aimi-meguru（G08） | A |
| S01 | 文倉 シオリ※ | `fumikura-shiori-sample` | fumikura-shiori（C09） | A |
| S03 | 附田 ユウ※ | `tsukuda-yu-sample` | tsukuda-yu（T14） | B |
